Next Release
============
* copy/paste/saving formatted text


Changelog
=========

0.1.1
=====
* many bugs removed
* much more usable in generall


Original Release 0.1.0
======================

